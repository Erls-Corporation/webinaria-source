//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Webinaria.rc
//
#define IDR_WEBINARIA_ACC               101
#define IDI_WEBINARIA_ICON              102
#define IDR_TRAY_MENU                   108
#define IDI_TRAY_FLASH                  117
#define IDD_DIALOG1                     124
#define IDD_REGION_SELECTOR             124
#define IDD_SOUND_INPUT_SETUP           125
#define IDC_BUTTON2                     1007
#define IDC_VOLUME                      1008
#define IDC_SLIDER1                     1009
#define IDC_VOLUME_CONTROL              1009
#define IDC_MUTE_SOUND                  1010
#define IDC_EDIT1                       1011
#define ID_RECORD                       40005
#define ID_STOP                         40006
#define ID_PAUSE                        40007
#define ID_HELP40008                    40008
#define ID_UPDATE                       40009
#define ID_EXIT                         40010
#define ID_RECORD40012                  40012
#define ID_PAUSERESUME                  40013
#define ID_RECORD_KEY                   40019
#define ID_PAUSERESUME_KEY              40020
#define ID_STOP_KEY                     40021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        128
#define _APS_NEXT_COMMAND_VALUE         40022
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
