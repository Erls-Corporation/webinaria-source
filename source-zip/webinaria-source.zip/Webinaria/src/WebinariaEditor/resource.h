//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Webinaria.rc
//
#define IDR_WEBINARIA_ACC               101
#define IDI_WEBINARIA_ICON              102
#define ID_TRACKBAR                     103
#define IDR_HTML1                       120
#define IDD_WEBCAM_CONTROL              121
#define IDB_CAMERA                      122
#define IDD_CONVERSION_QUALITY          123
#define IDD_TEXT_ELEMENT_EDITOR         125
#define IDR_OVERLAY_MENU                126
#define IDC_COMBO1                      1001
#define IDC_QUALITY                     1001
#define IDC_TEXT_ELEMENT_FONT_NAME      1001
#define IDC_TEXT_ELEMENT_TEXT           1002
#define IDC_TEXT_ELEMENT_ALIGN_LEFT     1003
#define IDC_TEXT_ELEMENT_ALIGN_CENTER   1004
#define IDC_TEXT_ELEMENT_ALIGN_RIGHT    1005
#define IDC_TEXT_ELEMENT_FONT           1006
#define IDC_TEXT_ELEMENT_COLOR          1007
#define IDC_BUTTON3                     1008
#define IDC_TEXT_ELEMENT_DELETE         1008
#define IDC_SLIDER1                     1009
#define IDC_TEXT_ELEMENT_FONT_SIZE      1009
#define ID_OVERLAYMENU_PROPERTIES       40015
#define ID_OVERLAYMENU_DELETE           40016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        127
#define _APS_NEXT_COMMAND_VALUE         40017
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
